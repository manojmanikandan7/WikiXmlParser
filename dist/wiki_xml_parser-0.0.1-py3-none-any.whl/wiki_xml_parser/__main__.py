"""

"""
if __name__ == "__main__":
    from wiki_xml_parser.cli import app
    app()